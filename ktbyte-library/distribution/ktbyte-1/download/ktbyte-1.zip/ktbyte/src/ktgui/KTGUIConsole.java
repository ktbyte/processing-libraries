package ktgui;

public class KTGUIConsole extends Controller {

	public KTGUIConsole(KTGUI ktgui) {
		super(ktgui);
	}

}
