/**
 * Provides the classes necessary to play sounds
 */
package ktbyte.sound;