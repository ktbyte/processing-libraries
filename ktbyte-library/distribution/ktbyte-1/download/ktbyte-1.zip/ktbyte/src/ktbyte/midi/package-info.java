/**
 * Provides the classes necessary to create midi music
 */
package ktbyte.midi;