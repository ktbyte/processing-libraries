/**
 * The package <b>ktgui</b> contains classes that implements the event 'transferring' from PApplet to the controllers
 *  
 */
package ktbyte.ktgui;